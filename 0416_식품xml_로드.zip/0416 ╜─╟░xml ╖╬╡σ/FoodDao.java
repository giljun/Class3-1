package db;

import java.sql.*;

public class FoodDao {
	// singleton
	private static FoodDao instance = new FoodDao();
	private FoodDao() {}
	public static FoodDao getInstance() {return instance;}
///////////////////////////////////////////////////
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
///////////////////////////////////////////////////
	public int insert(Food food) {
		con = DBUtil.makeConnection();
		String sql = "INSERT INTO FOOD_TB(CODE,NAME,SUPPORT_PER_EAT," + 
				"	CALORY,CARBO,PROTEIN,FAT,SUGAR,NATRIUM,CHOLE," + 
				"	FATTY_ACID,TRANS_FAT,MAKER,MATERIAL) "+ 
				"	VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		int result=0;
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, food.getCode());
			pstmt.setString(2, food.getName());
			pstmt.setDouble(3, food.getSupportpereat());
			pstmt.setDouble(4, food.getCalory());
			pstmt.setDouble(5, food.getCarbo());
			pstmt.setDouble(6, food.getProtein());
			pstmt.setDouble(7, food.getFat());
			pstmt.setDouble(8, food.getSugar());
			pstmt.setDouble(9, food.getNatrium());
			pstmt.setDouble(10, food.getChole());
			pstmt.setDouble(11, food.getFattyacid());
			pstmt.setDouble(12, food.getTransfat());
			pstmt.setString(13, food.getMaker());
			pstmt.setString(14, food.getMaterial());
			
			result = pstmt.executeUpdate();	// sql 실행		
		} catch (SQLException e) {
			System.out.println("insert 에러");
			e.printStackTrace();
		} finally {
			DBUtil.closePstmt(pstmt);
			DBUtil.closeCon(con);
		}
		return result;
	}
	
	
}




