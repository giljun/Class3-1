package db;

import java.sql.*;

public class DBUtil {
	private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DB_URL = 
			"jdbc:mysql://localhost:3306/ssafy_db?serverTimezone=UTC";
	private static final String DB_ID = "root";
	private static final String DB_PW = "ssafy";
	
	static {
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println("jar 파일 로딩 오류");
			e.printStackTrace();
		}
	}
	
	public static Connection makeConnection() {
		Connection con = null;
		
		try {
			// 실무에서는 아래 문장으로 커넥션 생성하지 않고 
			// 미리 여러개의 커넥션을 생성해둔 상태에서 커넥션을 가져다 사용하는 
			// DataBaseConnectionPool을 활용합니다.
			con = DriverManager.getConnection(DB_URL, DB_ID, DB_PW);
		} catch (SQLException e) {
			System.out.println("커넥션 생성 오류");
			e.printStackTrace();
		}
		return con;
	}
	
	public static void closeCon(Connection con) {
		if(con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void closePstmt(PreparedStatement pstmt) {
		if(pstmt!=null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void closeRs(ResultSet rs) {
		if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}







