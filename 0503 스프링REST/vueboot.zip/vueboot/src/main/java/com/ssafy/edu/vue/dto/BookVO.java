package com.ssafy.edu.vue.dto;
public class BookVO {
    private String title;
    private String imgURL;
    private String price;
    private String publisher;
    private String author;
 
    public String getTitle() {
        return title;
    }
 
    public void setTitle(String title) {
        this.title = title;
    }
 
    public String getImgURL() {
        return imgURL;
    }
 
    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }
 
    public String getPrice() {
        return price;
    }
 
    public void setPrice(String price) {
        this.price = price;
    }
 
    public String getPublisher() {
        return publisher;
    }
 
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
 
    public String getAuthor() {
        return author;
    }
 
    public void setAuthor(String author) {
        this.author = author;
    }
}