package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.MemberDTO;
import model.MemberService;

@WebServlet("/member.do")
public class MemberServlet extends HttpServlet {
	private MemberService service = MemberService.getInstance();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");
		String viewPath = "";
		
		if(action==null) {
			viewPath = "index.html";
		}else if(action.equals("joinForm")) {
			viewPath = "/member/join_form.jsp";
		}else if(action.equals("loginForm")) {
			viewPath = "/member/login_form.jsp";
		}
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPath);
		dispatcher.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");
		String viewPath = "";
		
		if(action!=null && action.equals("join")) {
			String user_id = req.getParameter("id");
			String user_pw = req.getParameter("pw");
			String email = req.getParameter("email");
			
			MemberDTO mem = new MemberDTO();
			mem.setId(user_id);
			mem.setEmail(email);
			mem.setPw(user_pw);
			
			if(service.join(mem)) {
				viewPath = "/member/join_success.jsp";
			}else {
				viewPath = "/member/join_fail.jsp";
			}
		}else if(action.equals("login")) {
			String userId = req.getParameter("userId");
			String userPw = req.getParameter("userPw");
			
			if(service.login(userId, userPw)) {
				HttpSession session = req.getSession();
				session.setAttribute("loginInfo", userId);
				viewPath = "/member/login_success.jsp";
			}else {
				viewPath = "/member/login_fail.jsp";
			}
		}
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPath);
		dispatcher.forward(req, resp);
	}
}














