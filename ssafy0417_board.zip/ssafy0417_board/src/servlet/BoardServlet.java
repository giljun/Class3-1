package servlet;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.BoardDTO;
import model.BoardPageDTO;
import model.BoardService;

@WebServlet("/board.do")
public class BoardServlet extends HttpServlet{
	private BoardService service = BoardService.getInstance();
		
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if(!loginCheck(req.getSession())) {
			resp.sendRedirect("member.do?action=loginForm");
			return;
		}
		
		String action = req.getParameter("action");
		String viewPath = "";
		
		if(action==null || action.equals("list")) {
			String p = req.getParameter("p");
			
			BoardPageDTO boardPage = service.makePage(p);
			req.setAttribute("boardPage", boardPage);
			viewPath = "/board/board_list.jsp";
		}else if(action.equals("writeForm")) {
			viewPath = "/board/write_form.jsp";
		}else if(action.equals("read")) {
			String ano = req.getParameter("ano");
			HttpSession session = req.getSession(); //글번호랑 지금 글 읽겠다는 놈 로그인 정보 같이 service한테 주기.
			BoardDTO board = service.read(ano, (String)session.getAttribute("loginInfo"));
			
			if(board==null) { // 글번호 파라미터가 안왔거나 없는 글번호였음.
				viewPath = "/board/read_fail.jsp";
			}else {
				req.setAttribute("board", board);
				viewPath = "/board/read.jsp";
			}
		}
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPath);
		dispatcher.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if(!loginCheck(req.getSession())) {
			resp.sendRedirect("member.do?action=loginForm");
			return;
		}
		
		req.setCharacterEncoding("euckr");
		
		String action = req.getParameter("action");
		String viewPath = "";
		
		if(action.equals("write")) {
			String title = req.getParameter("title");
			String content = req.getParameter("content");
			
			String[] pet = req.getParameterValues("pet");
			System.out.println(Arrays.toString(pet));
			
			BoardDTO board = new BoardDTO(title, content);
			String loginInfo = (String)req.getSession().getAttribute("loginInfo");
			board.setWriter(loginInfo);
			
			System.out.println(board);
			if(service.write(board)) {
				viewPath = "/board/write_success.jsp";
			}else {
				viewPath = "/board/write_fail.jsp";
			}
		}
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPath);
		dispatcher.forward(req, resp);
	}

	
	public boolean loginCheck(HttpSession session) {
		String loginInfo = (String)session.getAttribute("loginInfo");
		
		if(loginInfo==null || loginInfo.length()==0) // 로그인 안된 사람이네
			return false;
		
		return true;
	}
}










