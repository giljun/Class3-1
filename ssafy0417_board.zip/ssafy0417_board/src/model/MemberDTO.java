package model;

import java.util.Date;

public class MemberDTO {
	private int memberNum;
	private String id;
	private String pw;
	private String email;
	private Date joinDate;
///////////////////////////////////////////////////////////////////	
	public int getMemberNum() {
		return memberNum;
	}
	public void setMemberNum(int memberNum) {
		this.memberNum = memberNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	
	@Override
	public String toString() {
		return "MemberDTO [memberNum=" + memberNum + ", id=" + id + ", pw=" + pw + ", email=" + email + ", joinDate="
				+ joinDate + "]";
	}	
}
