package model;

public class MemberService {
	private static MemberService instance = new MemberService();
	private MemberService() {}
	public static MemberService getInstance() {
		return instance;
	}
///////////////////////////////////////////////////////////
	private MemberDao dao = MemberDao.getInstance();
	
	public boolean join(MemberDTO member) {
		if(dao.insert(member)==1) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean login(String id, String pw) {
		if(dao.selectMember(id, pw)==1) {
			return true;
		}else {
			return false;
		}
	}
}









