package model;

import java.util.Date;

public class BoardDTO {
	private int articleNo;
	private String title;
	private String writer;
	private String content;
//	private String writeDate;
	private Date writeDate;
	private int readCount;
////////////////////////////////////////////////////////////	
	public BoardDTO() {}
	
	public BoardDTO(String title, String content) {
		this.title = title;
		this.content = content;
	}
////////////////////////////////////////////////////////////	
	public int getArticleNo() {
		return articleNo;
	}
	public void setArticleNo(int articleNo) {
		this.articleNo = articleNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(Date writeDate) {
		this.writeDate = writeDate;
	}
	public int getReadCount() {
		return readCount;
	}
	public void setReadCount(int readCount) {
		this.readCount = readCount;
	}
	@Override
	public String toString() {
		return "BoardDTO [articleNo=" + articleNo + ", title=" + title + ", writer=" + writer + ", content=" + content
				+ ", writeDate=" + writeDate + ", readCount=" + readCount + "]";
	}	
}
