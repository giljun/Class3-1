package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public class BoardDao {
	private static BoardDao instance = new BoardDao();
	private BoardDao() {}
	public static BoardDao getInstance() {
		return instance;
	}
//////////////////////////////////////////////////////////////
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
///////////////////////////////////////////////////////////////	
	public int selectTotalCount() {
		con = DBUtil.makeConnection();
		String sql = "SELECT COUNT(*) FROM BOARD_TB";
		int result=0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			
			result = rs.getInt(1);
		} catch (SQLException e) {
			System.out.println("board dao selectCount 에러");
			e.printStackTrace();
		} finally {
			DBUtil.closeRs(rs);
			DBUtil.closePstmt(pstmt);
			DBUtil.closeCon(con);
		}
		
		return result;
	}
	
	public ArrayList<BoardDTO> selectList(int startRow, int count){
		con = DBUtil.makeConnection();
		String sql = "SELECT NO, TITLE, WRITER, WRITE_DATE, READ_COUNT "+
					"FROM BOARD_TB ORDER BY NO DESC LIMIT ?,?";
		
		ArrayList<BoardDTO> boardList = new ArrayList<>();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, count);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BoardDTO board = new BoardDTO();
				board.setArticleNo(rs.getInt(1));
				board.setTitle(rs.getString(2));
				board.setWriter(rs.getString(3));
				board.setWriteDate(new Date(rs.getTimestamp(4).getTime())); // 괜찮으려나 ... ;; 
				board.setReadCount(rs.getInt(5));
				
				boardList.add(board);
			}			
		} catch (SQLException e) {
			System.out.println("board dao selectList 에러");
			e.printStackTrace();
		} finally {
			DBUtil.closeRs(rs);
			DBUtil.closePstmt(pstmt);
			DBUtil.closeCon(con);
		}
		return boardList;
	}
	
	public int insert(BoardDTO board) {
		con = DBUtil.makeConnection();
		String sql = "INSERT INTO BOARD_TB (TITLE,WRITER,CONTENT,WRITE_DATE)"+
				"VALUES(?,?,?,NOW())";
		int result =0;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getWriter());
			pstmt.setString(3, board.getContent());
			
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public int updateReadCount(int articleNo) { // 조회수 증가 SQL
		con = DBUtil.makeConnection();
		String sql = "UPDATE BOARD_TB SET READ_COUNT=READ_COUNT+1 WHERE NO=?";
		int result = 0;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, articleNo);
			
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("board dao update 조회수 에러");
			e.printStackTrace();
		} finally {
			DBUtil.closePstmt(pstmt);
			DBUtil.closeCon(con);
		}
		return result;
	}
	
	public BoardDTO selectOne(int articleNo) { // 게시글 읽기할 때 1개 조회 메소드
		con = DBUtil.makeConnection();
		String sql = "SELECT NO,TITLE,WRITER,CONTENT,READ_COUNT,WRITE_DATE FROM BOARD_TB "
				+"WHERE NO=?";
		BoardDTO result = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, articleNo);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = new BoardDTO();
				result.setArticleNo(rs.getInt(1));
				result.setTitle(rs.getString(2));
				result.setWriter(rs.getString(3));
				result.setContent(rs.getString(4));
				result.setReadCount(rs.getInt(5));
				result.setWriteDate(new Date(rs.getTimestamp(6).getTime()));
			}
		} catch (SQLException e) {
			System.out.println("board dao selectOne 에러");
			e.printStackTrace();
		} finally {
			DBUtil.closeRs(rs);
			DBUtil.closePstmt(pstmt);
			DBUtil.closeCon(con);
		}
		return result;
	}
}











