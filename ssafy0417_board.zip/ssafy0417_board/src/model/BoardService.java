package model;

import java.util.ArrayList;

public class BoardService {
	private static BoardService instance = new BoardService();
	private BoardService() {}
	public static BoardService getInstance() {
		return instance;
	}
//////////////////////////////////////////////////////////////	
	private BoardDao dao = BoardDao.getInstance();
//////////////////////////////////////////////////////////////
	public static final int COUNT_PER_PAGE=10;
	
	public BoardPageDTO makePage(String p) {
		int page = 1;
		
		if(p!=null && p.length()>0) {
			page = Integer.parseInt(p);
		}
		
		int totalBoardCount = dao.selectTotalCount(); // 총 게시글 갯수 조회
		
		int totalPageCount = totalBoardCount/COUNT_PER_PAGE;
		if(totalBoardCount%COUNT_PER_PAGE != 0)
			totalPageCount++;
		
		int startRow = (page-1)*10;
		ArrayList<BoardDTO> boardList = dao.selectList(startRow, COUNT_PER_PAGE);
		
		int startPage = (page-1)/10*10+1;
		int endPage = startPage + 9;
		if(endPage > totalPageCount)
			endPage = totalPageCount;			
		
		return new BoardPageDTO(boardList, page, startPage, endPage, totalPageCount);
	}
	
	public boolean write(BoardDTO board) {
		if(dao.insert(board)==1) {
			return true;
		}else {
			return false;
		}
	}
	
	public BoardDTO read(String ano, String loginInfo) {
		BoardDTO result = null;
		
		if(ano!=null && ano.length()>0) {
			int articleNo = Integer.parseInt(ano);
			result = dao.selectOne(articleNo); // 게시글을 일단 조회해서 현재 로그인한 애가 쓴건지 검사하자.
			if(result!=null && !result.getWriter().equals(loginInfo)) {
				dao.updateReadCount(articleNo);
				result = dao.selectOne(articleNo); // 위에 update 반영된 내용으로 다시 select
			}
		}
		return result;
	}
}










