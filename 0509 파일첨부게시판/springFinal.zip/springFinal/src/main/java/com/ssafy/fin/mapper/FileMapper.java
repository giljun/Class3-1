package com.ssafy.fin.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.fin.dto.FileDTO;

@Mapper
public interface FileMapper {
	public int insertFile(FileDTO f);
	public List<FileDTO> selectFiles(int bnum);
	public FileDTO selectFile(int fnum);
}
