package com.ssafy.fin.dto;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class BoardDTO {
	private int bnum;
	private String btitle;
	private String bwriter;
	private Date bwriteDate;
	private int readCount;
	private String image;
	private String bcontents;
	private List<CommentDTO> commentList;
	private List<FileDTO> fileList;
	
	private MultipartFile imageFile; // 업로드 할때 대표이미지
	private List<MultipartFile> files; // 업로드 하는 파일	
	
	public MultipartFile getImageFile() {
		return imageFile;
	}
	public void setImageFile(MultipartFile imageFile) {
		this.imageFile = imageFile;
	}
	public List<MultipartFile> getFiles() {
		return files;
	}
	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}
	
	public int getBnum() {
		return bnum;
	}
	public void setBnum(int bnum) {
		this.bnum = bnum;
	}
	public String getBtitle() {
		return btitle;
	}
	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}
	public String getBwriter() {
		return bwriter;
	}
	public void setBwriter(String bwriter) {
		this.bwriter = bwriter;
	}
	public Date getBwriteDate() {
		return bwriteDate;
	}
	public void setBwriteDate(Date bwriteDate) {
		this.bwriteDate = bwriteDate;
	}
	public int getReadCount() {
		return readCount;
	}
	public void setReadCount(int readCount) {
		this.readCount = readCount;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getBcontents() {
		return bcontents;
	}
	public void setBcontents(String bcontents) {
		this.bcontents = bcontents;
	}
	public List<CommentDTO> getCommentList() {
		return commentList;
	}
	public void setCommentList(List<CommentDTO> commentList) {
		this.commentList = commentList;
	}
	public List<FileDTO> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileDTO> fileList) {
		this.fileList = fileList;
	}
	@Override
	public String toString() {
		return "BoardDTO [bnum=" + bnum + ", btitle=" + btitle + ", bwriter=" + bwriter + ", bwriteDate=" + bwriteDate
				+ ", readCount=" + readCount + ", image=" + image + ", bcontents=" + bcontents + ", commentList="
				+ commentList + ", fileList=" + fileList + "]";
	}
	
	
}
