package com.ssafy.fin.dto;

import java.util.List;

public class BoardPageDTO {
	private int curPage;
	private int startPage;
	private int endPage;
	private List<BoardDTO> boardList;
	private int totalPage;
	
	public BoardPageDTO() {}
	
	public BoardPageDTO(int curPage, int startPage, int endPage, List<BoardDTO> boardList, int totalPage) {
		this.curPage = curPage;
		this.startPage = startPage;
		this.endPage = endPage;
		this.boardList = boardList;
		this.totalPage = totalPage;
	}
	
	public int getCurPage() {
		return curPage;
	}
	public void setCurPage(int curPage) {
		this.curPage = curPage;
	}
	public int getStartPage() {
		return startPage;
	}
	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}
	public int getEndPage() {
		return endPage;
	}
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
	public List<BoardDTO> getBoardList() {
		return boardList;
	}
	public void setBoardList(List<BoardDTO> boardList) {
		this.boardList = boardList;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	@Override
	public String toString() {
		return "BoardPageDTO [curPage=" + curPage + ", startPage=" + startPage + ", endPage=" + endPage + ", boardList="
				+ boardList + ", totalPage=" + totalPage + "]";
	}	
}
