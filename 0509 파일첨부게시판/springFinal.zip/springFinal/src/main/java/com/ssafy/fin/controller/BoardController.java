package com.ssafy.fin.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.fin.dto.BoardDTO;
import com.ssafy.fin.dto.CommentDTO;
import com.ssafy.fin.dto.FileDTO;
import com.ssafy.fin.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	private BoardService service;
	public void setService(BoardService service) {
		this.service = service;
	}
	
	@RequestMapping("/")
	 public String index(){
	  return "index";
	 }
	
	@RequestMapping("/boardMain.do")
	public ModelAndView board(@RequestParam(name="p", defaultValue="1")int page) throws Exception {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("board_list"); // WEB-INF/views/board_list.jsp
		mv.addObject("boardPage",service.makePage(page));
		return mv;
	}
	
	@RequestMapping(value="/write.do", method=RequestMethod.GET)
	public String write() {
		return "write_form";
	}
	
	@RequestMapping(value="/write.do", method=RequestMethod.POST)
	public ModelAndView write(BoardDTO board, HttpServletRequest request) throws IllegalStateException, IOException {
		ModelAndView mv = new ModelAndView();
		if(service.write(board,request)) {
			mv.addObject("board", board);
			mv.setViewName("write_success");
		}else {
			mv.setViewName("write_fail");
		}
		return mv;
	}
	
	@RequestMapping(value="/read.do")
	public ModelAndView read(int boardNum) {
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("read");
		mv.addObject("board", service.read(boardNum));
		
		return mv;
	}
	
	@RequestMapping(value="/comment.do")
	@ResponseBody
	public List<CommentDTO> comment(int bnum) {
		return service.getComments(bnum);
	}
	
	@RequestMapping(value="/commentWrite.do")
	@ResponseBody
	public void comment(CommentDTO comment) {
		service.writeComment(comment);
	}
	
	@RequestMapping("/down.do")
	public void download(int fnum, HttpServletResponse response){
		FileDTO fileInfo = service.getFileInfo(fnum);
		
		response.setContentType
		("application/octet-stream; charset=UTF-8");
		response.setHeader
		("Content-Disposition", 
		"attachment; filename=\""+fileInfo.getOriginName()+"\"");
		
		try {
			// 읽어들이는 stream
			FileInputStream is = 
				new FileInputStream(fileInfo.getSavedPath());
			
			// 내보내는 stream
			ServletOutputStream os = response.getOutputStream();
			
			int data = 0;
			while((data = is.read()) != -1){
				os.write(data);
			}
			
			is.close();
			os.close();			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
//	
//	@ExceptionHandler(RuntimeException.class)
//	public ModelAndView exceptionParam(RuntimeException ex) {
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("error/error_page");
//		mv.addObject("error-info", ex.getMessage());
//		return mv;
//	}
}









