package com.ssafy.fin.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.fin.dto.CommentDTO;
@Mapper
public interface CommentMapper {
	public int insertComment(CommentDTO c);
	public List<CommentDTO> selectComments(int bnum);
}
