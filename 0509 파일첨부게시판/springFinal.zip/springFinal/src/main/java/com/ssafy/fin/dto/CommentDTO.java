package com.ssafy.fin.dto;

public class CommentDTO {
	private int cnum;
	private int bnum;
	private String cwriter;
	private String ccontents;
	
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	public int getBnum() {
		return bnum;
	}
	public void setBnum(int bnum) {
		this.bnum = bnum;
	}
	public String getCwriter() {
		return cwriter;
	}
	public void setCwriter(String cwriter) {
		this.cwriter = cwriter;
	}
	public String getCcontents() {
		return ccontents;
	}
	public void setCcontents(String ccontents) {
		this.ccontents = ccontents;
	}
	@Override
	public String toString() {
		return "CommentDTO [cnum=" + cnum + ", bnum=" + bnum + ", cwriter=" + cwriter + ", ccontents=" + ccontents
				+ "]";
	}
	
	
}
