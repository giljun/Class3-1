package com.ssafy.fin.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.fin.dto.BoardDTO;

@Mapper
public interface BoardMapper {
	public int insertBoard(BoardDTO b);
	public List<BoardDTO> selectBoards(@Param("stRow") int stRow,@Param("count") int count);
	public BoardDTO select(int bnum);
	public int updateReadCount(int bnum);
	public int totalCount();
	// update, delete 안했음.
}
