package com.ssafy.fin.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ssafy.fin.dto.BoardDTO;
import com.ssafy.fin.dto.BoardPageDTO;
import com.ssafy.fin.dto.CommentDTO;
import com.ssafy.fin.dto.FileDTO;
import com.ssafy.fin.mapper.BoardMapper;
import com.ssafy.fin.mapper.CommentMapper;
import com.ssafy.fin.mapper.FileMapper;

@Service
public class BoardService {
	@Autowired
	private BoardMapper bmapper;
	@Autowired
	private FileMapper fmapper;
	@Autowired
	private CommentMapper cmapper;

	public BoardPageDTO makePage(int page) {
		int totalBoardCount = bmapper.totalCount(); // 총 게시글 갯수
		final int COUNT_PER_PAGE = 10;

		if (totalBoardCount == 0) // 게시글 없네.
			return null;

		int startRow = (page - 1) * COUNT_PER_PAGE; // 게시글 몇번째꺼부터 끊어서 select 할지 계산
		List<BoardDTO> boardList = bmapper.selectBoards(startRow, COUNT_PER_PAGE);

		int totalPage = totalBoardCount / COUNT_PER_PAGE; // 총 게시글에 필요한 총 페이지수 계산
		if (totalBoardCount % COUNT_PER_PAGE != 0)
			totalPage++;

		int startPage = (page - 1) / 10 * 10 + 1; // 목록 하단에 시작페이지 링크 계산
		int endPage = startPage + 9; // 목록 하단에 끝페이지 링크 계산
		if (endPage > totalPage)
			endPage = totalPage;

		return new BoardPageDTO(page, startPage, endPage, boardList, totalPage);
	}

	

	public boolean write(BoardDTO board, HttpServletRequest request) throws IllegalStateException, IOException {
		// 대표 이미지 업로드 하고 board_tb에 게시글 저장
		String imgPath = request.getServletContext().getRealPath("img");

		File dir = new File(imgPath);
		if (dir.exists() == false) // 대표이미지 폴더가 없으면 생성하라.
			dir.mkdir();

		String savedImgName = imgPath + "/" + board.getImageFile().getOriginalFilename();
		
		File savedImgFile = new File(savedImgName);// 랜덤 이름으로 빈 파일 하나 만들기
		board.getImageFile().transferTo(savedImgFile);// 사용자가 업로드 한 파일을 빈 파일로 복사하기

		board.setImage("img/" + board.getImageFile().getOriginalFilename());
		int result = bmapper.insertBoard(board); // 게시글 저장
		//////////////////////////////////////////////////////////////////////////
		// 게시글 번호 가지고 파일 여러개 업로드 
		String fileDir = "c:/springFiles";
		File fdir = new File(fileDir);
		if (fdir.exists() == false)
			fdir.mkdir();

		for (MultipartFile uploadFile : board.getFiles()) {
			String savedName = fileDir + "/" + new Random().nextInt(100000000);

			File savedFile = new File(savedName);
			
			uploadFile.transferTo(savedFile);// 사용자가 업로드 한 파일을 빈 파일로 복사하기
			FileDTO tmp = new FileDTO();
			tmp.setOriginName(uploadFile.getOriginalFilename());
			tmp.setSavedPath(savedFile.getAbsolutePath());
			tmp.setBnum(board.getBnum());
			fmapper.insertFile(tmp);
		}
		return true;
	}
	
	public BoardDTO read(int bnum) {
		BoardDTO board = bmapper.select(bnum);
		bmapper.updateReadCount(bnum);
		board.setFileList(fmapper.selectFiles(bnum));
		return board;
	}
	
	public List<CommentDTO> getComments(int bnum){
		return cmapper.selectComments(bnum);
	}
	
	public void writeComment(CommentDTO comment) {
		cmapper.insertComment(comment);
	}
	public FileDTO getFileInfo(int fnum) {
		return fmapper.selectFile(fnum);
	}
}
